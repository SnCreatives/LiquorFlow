export const CANONICAL_CATEGORY_ORDER = [
  'Whisky',
  'Rum',
  'Vodka',
  'Gin',
  'Brandy',
  'Beer',
  'Wine',
] as const;

export const CANONICAL_BRAND_MASTER: Record<string, string[]> = {
  Whisky: [
    'Royal Stag',
    'Blenders Pride',
    'Imperial Blue',
    "McDowell's No.1",
    'Signature',
    "Officer's Choice",
    'Sterling Reserve',
    '8 PM',
    'Rockford',
    'Antiquity',
    'Royal Challenge',
    'DSP Black',
    "Director's Special",
    'Peter Scot',
    'Bagpiper',
    'Aristocrat',
    'White & Blue',
    'Black Dog',
    '100 Pipers',
    "Ballantine's",
    'Chivas Regal',
    'Johnnie Walker',
    "Teacher's",
    'VAT 69',
    'The Glenlivet',
  ],
  Rum: [
    'Old Monk',
    "McDowell's No.1 Celebration",
    'Bacardi',
    'Captain Morgan',
    'Contessa',
    'Hercules',
    'Maka Zai',
  ],
  Vodka: [
    'Magic Moments',
    'Magic Moments Grain',
    'Magic Moments Pure Grain',
    'Magic Moments Remix',
    'Magic Moments Minty Jamun',
    'Mango Mirchi',
    'Sea Link',
    'Smirnoff',
    'Absolut',
    'Romanov',
    'White Mischief',
    'Fuel',
  ],
  Gin: [
    'Blue Riband',
    "Gordon's",
    'Bombay Sapphire',
    'Tanqueray',
    'Greater Than',
    'Hapusa',
    'Jaisalmer',
  ],
  Brandy: [
    'Mansion House',
    "McDowell's No.1 Brandy",
    'Honey Bee',
    'Morpheus',
    'Dreher',
    'St-Rémy',
  ],
  Beer: [
    'Kingfisher',
    'Budweiser',
    'Tuborg',
    'Carlsberg',
    'Heineken',
    'Corona',
    "Foster's",
    'Haywards',
    'bira 91',
    'Hoegaarden',
    'Stella Artois',
    "Beck's",
    'Simba',
    'White Owl',
    'Miller',
  ],
  Wine: [
    'Sula',
    'Fratelli',
    'York',
    'Grover Zampa',
    'Reveilo',
    'Myra',
    'Four Seasons',
    'Nine Hills',
    'Big Banyan',
  ],
};

// Map lowercase brand name -> canonical index for deterministic sorting
const BRAND_ORDER_INDEX = new Map<string, number>();
Object.values(CANONICAL_BRAND_MASTER)
  .flat()
  .forEach((name, idx) => {
    BRAND_ORDER_INDEX.set(name.toLowerCase(), idx);
  });

export function compareCanonicalBrands(nameA: string, nameB: string): number {
  const idxA = BRAND_ORDER_INDEX.get((nameA || '').toLowerCase());
  const idxB = BRAND_ORDER_INDEX.get((nameB || '').toLowerCase());
  if (idxA !== undefined && idxB !== undefined) return idxA - idxB;
  if (idxA !== undefined) return -1;
  if (idxB !== undefined) return 1;
  return (nameA || '').localeCompare(nameB || '', undefined, { sensitivity: 'base' });
}
