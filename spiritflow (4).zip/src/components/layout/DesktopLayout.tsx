import React, { ReactNode } from 'react';
import { AuthUser } from '../../types';
import { Sidebar } from '../common/Sidebar';
import { Header } from '../common/Header';

interface DesktopLayoutProps {
  user: AuthUser;
  currentRoute: string;
  onRouteChange: (route: string) => void;
  onLogout: () => void;
  onOpenSearch: () => void;
  children: ReactNode;
}

export const DesktopLayout: React.FC<DesktopLayoutProps> = ({
  user,
  currentRoute,
  onRouteChange,
  onLogout,
  onOpenSearch,
  children,
}) => {
  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 selection:bg-amber-500 selection:text-slate-950 font-sans">
      {/* Persistent Left Desktop Sidebar */}
      <aside className="w-64 shrink-0 border-r border-slate-200 bg-white min-h-screen sticky top-0 h-screen overflow-y-auto">
        <Sidebar
          currentRoute={currentRoute}
          onRouteChange={onRouteChange}
          user={user}
          onLogout={onLogout}
        />
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          user={user}
          onLogout={onLogout}
          onOpenSearch={onOpenSearch}
          currentRoute={currentRoute}
          onRouteChange={onRouteChange}
        />

        <main className="flex-1 pb-16 px-6 py-6 max-w-full">
          {children}
        </main>
      </div>
    </div>
  );
};
