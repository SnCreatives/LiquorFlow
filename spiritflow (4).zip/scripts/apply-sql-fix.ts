import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    console.error('DATABASE_URL not found');
    return;
  }

  console.log('Connecting to database...');
  const client = new pg.Client({
    connectionString,
    ssl: {
      rejectUnauthorized: false
    }
  });

  try {
    await client.connect();
    console.log('✅ Connected successfully');

    const sql = `
      -- 1. Add sold_quantity column to inventory
      ALTER TABLE public.inventory ADD COLUMN IF NOT EXISTS sold_quantity NUMERIC(12, 2) NOT NULL DEFAULT 0;

      -- 2. Update the trigger function
      CREATE OR REPLACE FUNCTION public.update_inventory_current_stock()
      RETURNS TRIGGER AS $$
      BEGIN
          NEW.current_quantity := NEW.opening_quantity + NEW.purchased_quantity + NEW.adjustment_quantity + NEW.returned_quantity - NEW.sold_quantity;
          
          IF NEW.current_quantity < 0 THEN
              RAISE EXCEPTION 'Stock violation: Current stock cannot be negative (calculated: %)', NEW.current_quantity;
          END IF;
          
          NEW.updated_at := NOW();
          RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;

      -- 3. Backfill
      DO $$
      DECLARE
          item RECORD;
      BEGIN
          FOR item IN 
              SELECT product_id, bar_id, SUM(quantity) as total_sold
              FROM public.sales_transaction_items
              GROUP BY product_id, bar_id
          LOOP
              UPDATE public.inventory
              SET sold_quantity = item.total_sold
              WHERE product_id = item.product_id AND bar_id = item.bar_id;
          END LOOP;
      END $$;
    `;

    console.log('Executing SQL...');
    await client.query(sql);
    console.log('✅ SQL executed successfully');

  } catch (err: any) {
    console.error('❌ Error:', err.message);
  } finally {
    await client.end();
  }
}

run();
