import { getSupabaseServiceClient } from '../src/lib/supabase/client.js';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const supabase = getSupabaseServiceClient();
  console.log('✅ Connected to Supabase');

  // Check inventory columns
  const { data: columns, error: cErr } = await supabase.rpc('get_table_columns', { p_table_name: 'inventory' });
  
  if (cErr) {
    // If RPC doesn't exist, try a direct query to information_schema
    const { data: infoCols, error: infoErr } = await supabase
      .from('inventory')
      .select('*')
      .limit(1);
    
    if (infoErr) {
        console.error('Error fetching inventory record:', infoErr.message);
    } else {
        console.log('Inventory sample record keys:', Object.keys(infoCols[0] || {}));
    }
  } else {
    console.log('Inventory columns:', columns);
  }

  // Check a sample product's inventory and ledger
  const { data: sampleInv } = await supabase.from('inventory').select('*, product:products(name)').limit(5);
  console.log('Sample Inventory Records:', JSON.stringify(sampleInv, null, 2));

  // Check sales transaction items count
  const { count: salesCount } = await supabase.from('sales_transaction_items').select('*', { count: 'exact', head: true });
  console.log('Total sales transaction items:', salesCount);
}

run();
