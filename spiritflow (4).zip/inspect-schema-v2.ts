import { getSupabaseServiceClient } from './src/lib/supabase/client.js';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const supabase = getSupabaseServiceClient();
  console.log('✅ Connected via Supabase JS Client!');

  const tables = ['brands', 'products', 'purchase_items'];
  
  for (const table of tables) {
    console.log(`\n--- Schema for ${table} ---`);
    const { data, error } = await supabase.from(table).select('*').limit(1);
    if (error) {
      console.error(`Error fetching ${table}:`, error.message);
    } else if (data && data.length > 0) {
      console.log(Object.keys(data[0]));
    } else {
      console.log('Table is empty, trying to get column names via select(null)...');
      const { data: cols, error: colErr } = await supabase.from(table).select('*').limit(0);
      console.log(Object.keys(cols || {}));
    }
  }

  // Check for "Unknown Brand"
  console.log('\n--- Checking for "Unknown Brand" records ---');
  const { data: unknownBrands, error: ubErr } = await supabase
    .from('brands')
    .select('id, name')
    .ilike('name', '%unknown%');
  
  if (ubErr) {
    console.error('Error fetching unknown brands:', ubErr.message);
  } else {
    console.log(`Found ${unknownBrands?.length || 0} brands matching "unknown"`);
    unknownBrands?.forEach(b => console.log(`ID: ${b.id}, Name: ${b.name}`));
  }

  // Check Magic Moments
  console.log('\n--- Checking for Magic Moments records ---');
  const { data: mmBrands, error: mmErr } = await supabase
    .from('brands')
    .select('id, name')
    .ilike('name', '%Magic Moments%');
  
  if (mmErr) {
    console.error('Error fetching Magic Moments brands:', mmErr.message);
  } else {
    console.log(`Found ${mmBrands?.length || 0} brands matching "Magic Moments"`);
    mmBrands?.forEach(b => console.log(`ID: ${b.id}, Name: ${b.name}`));
  }
}

run();
