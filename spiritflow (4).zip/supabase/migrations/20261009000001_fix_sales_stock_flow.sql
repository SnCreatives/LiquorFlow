-- Bug Fix: Sales quantity not updating in stock / inward flow
-- Objective: Add sold_quantity to inventory and update trigger to include it in stock calculation.

-- 1. Add sold_quantity column to inventory
ALTER TABLE public.inventory ADD COLUMN IF NOT EXISTS sold_quantity NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (sold_quantity >= 0);

-- 2. Update the trigger function to include sold_quantity in current_quantity calculation
CREATE OR REPLACE FUNCTION public.update_inventory_current_stock()
RETURNS TRIGGER AS $$
BEGIN
    -- Formula: Current = Opening + Purchased + Adjustments + Returned - Sold
    NEW.current_quantity := NEW.opening_quantity + NEW.purchased_quantity + NEW.adjustment_quantity + NEW.returned_quantity - NEW.sold_quantity;
    
    IF NEW.current_quantity < 0 THEN
        RAISE EXCEPTION 'Stock violation: Current stock cannot be negative (calculated: %)', NEW.current_quantity;
    END IF;
    
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. Backfill sold_quantity from existing sales_transaction_items (Safely)
DO $$
DECLARE
    item RECORD;
BEGIN
    FOR item IN 
        SELECT product_id, bar_id, SUM(quantity) as total_sold
        FROM public.sales_transaction_items
        GROUP BY product_id, bar_id
    LOOP
        UPDATE public.inventory
        SET sold_quantity = item.total_sold
        WHERE product_id = item.product_id AND bar_id = item.bar_id;
    END LOOP;
END $$;
